<?php

return [
    'name' => 'FrontModule',
    'prefix'=> 'ar',
];
