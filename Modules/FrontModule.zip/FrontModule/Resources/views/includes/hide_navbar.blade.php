<section class="hidden-bar right-align">
    <div class="hidden-bar-closer">
        <button><span class="flaticon-remove"></span></button>
    </div>
    <div class="hidden-bar-wrapper">
        <div class="logo">
            <a href="index.html"><img src="{{ url('assets/front') }}/images/resources/logo-2.png" alt=""/></a>
        </div>
        <div class="content-box">
            <h2>About Us</h2>
            <div class="text">iFIXFAST - Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps.</div>
            <a href="#" class="btn-one">Consultation</a>
        </div>
        <div class="contact-info">
            <h2>Contact Info</h2>
            <ul>
                <li><span class="icon fa fa-map-marker"></span>106 Boulevard Malesherbes 75017 Paris.</li>
                <li><a href="#"><span class="icon fa fa-phone"></span>+33 (0)1 80 48 96 00</a></li>
                <li><a href="info@Livornobitcoin.com"><span class="icon fa fa-envelope-o"></span>Info@iFIXFAST.com</a></li>
            </ul>
        </div>
    </div>
</section>