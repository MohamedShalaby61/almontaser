{{--{{ dd($sliders) }}--}}
@extends('frontmodule::layouts.app')

@section('content')
    <section class="welcome-area sec-pd1">
        <div class="container">
            <div class="sec-title max-width text-center">
                <h3>@lang('frontmodule::front.welcome_message')</h3>
                <h1>@lang('frontmodule::front.success_words')</h1>
            </div>
            <div class="row">

            </div>
        </div>
    </section>
@endsection
